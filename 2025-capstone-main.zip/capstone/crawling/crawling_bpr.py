import os
import xml.etree.ElementTree as ET
import requests
import json

API_KEY = "3f137e287df400d204dfc01605363fbe7b310bcb"

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
CORPCODE_PATH = os.path.join(BASE_DIR, "corp_data", "CORPCODE.xml")

# 저장 경로 지정
SAVE_DIR = os.path.join(BASE_DIR, "static", "data")

def get_corp_code(stock_code, corpcode_xml_path=CORPCODE_PATH):
    tree = ET.parse(corpcode_xml_path)
    root = tree.getroot()
    for child in root.findall("list"):
        if child.find("stock_code").text == stock_code:
            return child.find("corp_code").text
    raise ValueError(f"stock_code {stock_code}에 해당하는 corp_code가 없습니다.")

def fetch_financial_data(corp_code, bgn_de, reprt_code):
    url = "https://opendart.fss.or.kr/api/fnlttSinglAcnt.json"
    params = {
        "crtfc_key": API_KEY,
        "corp_code": corp_code,
        "bsns_year": bgn_de,
        "reprt_code": reprt_code,
        "fs_div": "CFS",  # 연결재무제표
        "api_type": "json",
    }
    response = requests.get(url, params=params)
    data = response.json()
    if data["status"] != "000":
        raise Exception(f"API 오류: {data.get('message', '')}")
    return data

def save_to_json(data, filename):
    with open(filename, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=4)

def calculate_ratios(items):
    # 필요한 계정명 초기화
    data = {
        "자산총계": 0, "부채총계": 0, "자본총계": 0, "유동자산": 0, "유동부채": 0,
        "매출액": 0, "영업이익": 0, "당기순이익": 0
    }
    for item in items:
        account_nm = item.get("account_nm")
        amount = item.get("thstrm_amount")
        if amount and amount.replace(',', '').isdigit():
            amount_int = int(amount.replace(',', ''))
        else:
            amount_int = 0

        if account_nm in data:
            data[account_nm] = amount_int

    shares_outstanding = 1000000000  # 예시: 10억주 (실제 발행주식수 필요시 별도 로직 필요)

    def safe_div(numerator, denominator):
        if denominator == 0:
            return "--"
        return round(numerator / denominator, 2)

    def safe_div_percent(numerator, denominator):
        if denominator == 0:
            return "--"
        return round((numerator / denominator) * 100, 2)

    eps = safe_div(data["당기순이익"], shares_outstanding)
    bps = safe_div(data["자본총계"], shares_outstanding)
    roe = safe_div_percent(data["당기순이익"], data["자본총계"])
    roa = safe_div_percent(data["당기순이익"], data["자산총계"])
    debt_ratio = safe_div_percent(data["부채총계"], data["자본총계"])
    current_ratio = safe_div_percent(data["유동자산"], data["유동부채"])
    operating_margin = safe_div_percent(data["영업이익"], data["매출액"])
    net_profit_margin = safe_div_percent(data["당기순이익"], data["매출액"])

    return {
        "EPS": eps,
        "BPS": bps,
        "ROE(%)": roe,
        "ROA(%)": roa,
        "부채비율(%)": debt_ratio,
        "유동비율(%)": current_ratio,
        "영업이익률(%)": operating_margin,
        "순이익률(%)": net_profit_margin
    }

def process_company(stock_code):
    try:
        corp_code = get_corp_code(stock_code)
    except ValueError as e:
        print(f"{stock_code} 처리 중 오류: {e}")
        return

    years = ["2024", "2023", "2022"]
    reprt_code = "11011"  # 사업보고서(연간)

    result = {}

    for year in years:
        try:
            response = fetch_financial_data(corp_code, year, reprt_code)
            items = response.get("list", [])
            if not items:
                print(f"{stock_code} - {year} 데이터가 없습니다.")
        except Exception as e:
            print(f"{stock_code} - {year} 처리 중 오류: {e}")
            items = []  # 오류시 빈 리스트 처리

        ratios = calculate_ratios(items)
        result[year] = ratios

    filename = f"{stock_code}_투자지표.json"
    save_to_json(result, filename)
    print(f"{filename} 저장 완료. ✅ 투자지표 저장완료")

if __name__ == "__main__":
    stock_codes = [
        "211270",  # AP위성
        "194480",  # 데브시스터즈
        "452280",  # 한선엔지니어링
        "002240",  # 고려제강
        "241770",  # 메카로
        "006800",  # 미래에셋증권
        "039980",  # 폴라리스AI
        "215100",  # 로보로보
        "208370",  # 셀바스헬스케어
        "015750",  # 성우하이텍
    ]

    for code in stock_codes:
        process_company(code)
